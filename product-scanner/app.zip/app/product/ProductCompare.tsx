"use client";

import { useState, type FormEvent } from "react";
import StoreOffers from "./StoreOffers";

type Nutriments = Record<string, number | string | undefined>;
type CompareProduct = {
  code: string;
  name: string;
  brand: string;
  quantity: string;
  ingredients: string;
  allergens: string;
  nutriments: Nutriments;
};

type Props = {
  current: CompareProduct;
};

const nutrientRows = [
  ["energy-kcal_100g", "Энергия", "ккал"],
  ["proteins_100g", "Белки", "г"],
  ["fat_100g", "Жиры", "г"],
  ["carbohydrates_100g", "Углеводы", "г"],
  ["sugars_100g", "Сахара", "г"],
  ["salt_100g", "Соль", "г"],
] as const;

export default function ProductCompare({ current }: Props) {
  const [code, setCode] = useState("");
  const [other, setOther] = useState<CompareProduct | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function compare(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = code.trim().replace(/\s+/g, "");
    if (!/^\d{8,14}$/.test(normalized)) {
      setError("Введи штрихкод второго товара (8–14 цифр).");
      setOther(null);
      return;
    }
    if (normalized === current.code) {
      setError("Это уже открытый товар. Введи другой штрихкод.");
      setOther(null);
      return;
    }
    setLoading(true);
    setError("");
    setOther(null);
    try {
      const fields = "code,product_name,generic_name,brands,quantity,ingredients_text,ingredients_text_ru,allergens,nutriments";
      const response = await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(normalized)}?fields=${fields}`);
      if (!response.ok) throw new Error("Не удалось получить данные второго товара.");
      const data = await response.json();
      if (data.status !== 1 || !data.product) throw new Error("Второй товар не найден в Open Food Facts.");
      const p = data.product;
      setOther({
        code: p.code || normalized,
        name: p.product_name?.trim() || p.generic_name?.trim() || "Название не указано",
        brand: p.brands?.trim() || "",
        quantity: p.quantity?.trim() || "",
        ingredients: p.ingredients_text_ru?.trim() || p.ingredients_text?.trim() || "",
        allergens: p.allergens?.trim() || "",
        nutriments: p.nutriments || {},
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка загрузки второго товара.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="product-section product-compare-section">
      <h2>Сравнить с другим товаром</h2>
      <p className="product-section-hint">Введи штрихкод второго продукта. Состав и пищевая ценность загружаются из Open Food Facts; цена — из локальной базы приложения, если товар там есть.</p>
      <form className="compare-form" onSubmit={compare}>
        <input aria-label="Штрихкод второго товара" value={code} onChange={(e) => setCode(e.target.value)} placeholder="Например, 5449000000996" inputMode="numeric" />
        <button className="primary-button" type="submit" disabled={loading}>{loading ? "Загружаем…" : "Сравнить"}</button>
      </form>
      {error && <p className="form-error">{error}</p>}
      {other && (
        <>
          <div className="compare-products-grid">
            {[current, other].map((p) => (
              <article className="compare-product-card" key={p.code}>
                <p className="product-label">{p.code === current.code ? "ТЕКУЩИЙ ТОВАР" : "ВТОРОЙ ТОВАР"}</p>
                <h3>{p.name}</h3>
                {p.brand && <p>{p.brand}</p>}
                {p.quantity && <p>{p.quantity}</p>}
                <p className="compare-ingredients"><strong>Состав:</strong> {p.ingredients || "Нет данных в базе"}</p>
                <p className="compare-ingredients"><strong>Аллергены:</strong> {p.allergens || "Нет данных; это не означает, что аллергенов нет."}</p>
              </article>
            ))}
          </div>
          <div className="compare-nutrition-table">
            <div className="compare-nutrition-row compare-nutrition-header"><span>На 100 г</span><strong>{current.name}</strong><strong>{other.name}</strong></div>
            {nutrientRows.map(([key, label, unit]) => (
              <div className="compare-nutrition-row" key={key}>
                <span>{label}</span>
                <strong>{current.nutriments[key] == null || current.nutriments[key] === "" ? "Нет данных" : `${Number(current.nutriments[key]).toLocaleString("ru-RU", { maximumFractionDigits: 2 })} ${unit}`}</strong>
                <strong>{other.nutriments[key] == null || other.nutriments[key] === "" ? "Нет данных" : `${Number(other.nutriments[key]).toLocaleString("ru-RU", { maximumFractionDigits: 2 })} ${unit}`}</strong>
              </div>
            ))}
          </div>
          <StoreOffers code={other.code} brand={other.brand} productName={other.name} />
        </>
      )}
    </section>
  );
}
